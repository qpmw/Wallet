package com.to.frownies.carrier.transaction;

public record ReqUserWithdrawCarrier (Long amount){
}
