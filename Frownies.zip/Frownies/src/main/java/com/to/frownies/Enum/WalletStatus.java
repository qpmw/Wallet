package com.to.frownies.Enum;

public enum WalletStatus {
    BLOCKED, BANNED, NORMAL, CLOSED
}
