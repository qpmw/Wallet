package com.to.frownies.carrier.user;

public record ReqRegisterCarrier(String username, String password, String fullName, String mobileNumber) {
}
