package com.to.frownies.entity;

import lombok.*;
import org.springframework.data.couchbase.core.mapping.Document;
import org.springframework.data.couchbase.core.mapping.Field;

import java.time.Instant;
import java.util.UUID;

@Data
@Document
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@RequiredArgsConstructor
public class Transaction extends BaseEntity {
    @Field
    private long amount;
    @Field
    private UUID sourceWallet;
    @Field
    private UUID destinationWallet;

    public Transaction(long amount, UUID sourceWallet, UUID destinationWallet, Instant createdDate) {
        this.amount = amount;
        this.sourceWallet = sourceWallet;
        this.destinationWallet = destinationWallet;
        setCreatedDate(createdDate);
    }

    public long getAmount() {
        return amount;
    }

    public void setAmount(long amount) {
        this.amount = amount;
    }

    public UUID getSourceWallet() {
        return sourceWallet;
    }

    public void setSourceWallet(UUID sourceWallet) {
        this.sourceWallet = sourceWallet;
    }

    public UUID getDestinationWallet() {
        return destinationWallet;
    }

    public void setDestinationWallet(UUID destinationWallet) {
        this.destinationWallet = destinationWallet;
    }
}
