package com.to.frownies.carrier.transaction;

import java.util.List;
import java.util.UUID;

public record ResTranListCarrier (List<UUID> list){
}
