package com.to.frownies.carrier.user;

public record ReqLoginCarrier (String username, String password){
}
