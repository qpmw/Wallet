package com.to.frownies.carrier.transaction;

public record ResBalanceCarrier (Long balance){
}
