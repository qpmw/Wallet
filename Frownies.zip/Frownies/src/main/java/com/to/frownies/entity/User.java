package com.to.frownies.entity;

import lombok.*;
import org.springframework.data.couchbase.core.mapping.Document;
import org.springframework.data.couchbase.core.mapping.Field;

import java.util.UUID;

@Data
@Document
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@RequiredArgsConstructor
public class User extends EditableEntity {
    @Field
    @NonNull
    private String username;
    @Field
    @NonNull
    private String password;
    @Field
    @NonNull
    private String fullName;
    @Field
    @NonNull
    private String mobileNumber;
    @Field
    private String address;
    @Field
    private String email;
    @Field
    private boolean admin = false;
    @Field
    private UUID walletId;

    public User(@NonNull String username, @NonNull String password, @NonNull String fullName, @NonNull String mobileNumber, UUID createdBy) {
        this.username = username;
        this.password = password;
        this.fullName = fullName;
        this.mobileNumber = mobileNumber;
        assert createdBy != null;
        setCreatedBy(createdBy);
    }

    public User(@NonNull String username, @NonNull String password, @NonNull String fullName, @NonNull String mobileNumber, UUID createdBy, boolean admin) {
        this.username = username;
        this.password = password;
        this.fullName = fullName;
        this.mobileNumber = mobileNumber;
        this.admin = admin;
        assert createdBy != null;
        setCreatedBy(createdBy);
    }

    public String getUsername() {
        return username;
    }


    public User(){}
    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean isAdmin() {
        return admin;
    }

    public void setAdmin(boolean admin) {
        this.admin = admin;
    }

    public UUID getWalletId() {
        return walletId;
    }

    public void setWalletId(UUID walletId) {
        this.walletId = walletId;
    }
}
