package com.to.frownies;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FrowniesApplicationTests {

    @Test
    void contextLoads() {
    }

}
